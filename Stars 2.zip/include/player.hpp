#ifndef PLAYER_HPP
#define PLAYER_HPP

#include <vector>
#include "SFML/Graphics.hpp"
#include "bullet.hpp"
class player
{
    public:
        player();
        sf::Sprite sprite();
        void update(int frame);

    sf::Texture texture;
    sf::Texture texture_bullet;
    sf::Sprite skin;
    std::vector<bullet> bullets;
    float x;
    float y;

    sf::RectangleShape skin_ammo;
    int ammo;
    int shoot_type;

};

#endif // PLAYER_HPP

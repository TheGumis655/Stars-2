#ifndef ENEMY_HPP
#define ENEMY_HPP

#include "SFML/Graphics.hpp"

class enemy
{
    public:
        enemy(sf::Texture& texture);
        bool update();

        float x;
        float y;
        sf::Sprite skin;

};

#endif // ENEMY_HPP

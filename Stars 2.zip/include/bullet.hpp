#ifndef BULLET_HPP
#define BULLET_HPP

#include "SFML/Graphics.hpp"

class bullet
{
    public:
        bullet(float& x,float& y, sf::Texture& texture);
        sf::Sprite skin;

        bool update();
        sf::Vector2f pos;

};

#endif // BULLET_HPP
